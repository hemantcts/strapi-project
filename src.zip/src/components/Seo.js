import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
// import axios from 'axios';

const SEO = ({ slug }) => {
  const [seoData, setSeoData] = useState(null);

  useEffect(() => {
    const fetchSEO = async () => {
      try {
        const response = await fetch(`https://medzentrum.entwicklung-loewenmut.ch/api/pages?filters[Slug][$eq]=${slug}&populate[Seo][populate]=shareImage`);
        const data = await response.json();
        const pageData = data.data[0];

        console.log("seo data", pageData)

        if (pageData && pageData.Seo) {
          setSeoData(pageData.Seo);
        }
      } catch (error) {
        console.error('Error fetching SEO data:', error);
      }
    };

    fetchSEO();
  }, [slug]);

  if (!seoData) return null;

  const { metaTitle, metaDescription, shareImage } = seoData;
  const imageUrl = shareImage?.url
    ? `https://medzentrum.entwicklung-loewenmut.ch${shareImage.url}`
    : '';

  return (
    <Helmet>
      <title>{metaTitle}</title>
      <meta name="description" content={metaDescription} />

      {/* Open Graph / Facebook */}
      <meta property="og:title" content={metaTitle} />
      <meta property="og:description" content={metaDescription} />
      {imageUrl && <meta property="og:image" content={imageUrl} />}
      <meta property="og:type" content="website" />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={metaTitle} />
      <meta name="twitter:description" content={metaDescription} />
      {imageUrl && <meta name="twitter:image" content={imageUrl} />}
    </Helmet>
  );
};

export default SEO;
